package com.vaannila;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class QuizProgram {
	public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");//读取beans.xml中的内容
		QuizMasterService quizMasterService = (QuizMasterService)ctx.getBean("quizMasterService");

		quizMasterService.askQuestion();
	}
}
