package com.vaannila;

public interface QuizMaster {
	public String popQuestion();
}
